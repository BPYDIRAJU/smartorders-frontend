// src/pages/callback.tsx
import { useEffect } from "react";
import { useAuth } from "react-oidc-context";
import { useNavigate } from "react-router-dom";

export default function CallbackPage() {
  const auth = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (auth.isAuthenticated) {
      navigate("/dashboard"); // ✅ redirect after successful login
    }
  }, [auth.isAuthenticated]);

  return (
    <div className="flex items-center justify-center h-screen">
      <p className="text-lg text-gray-600">Signing in...</p>
    </div>
  );
}

