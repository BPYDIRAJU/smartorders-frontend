// src/pages/Orders.tsx

const orders = [
  {
    id: 101,
    customer: "John Doe",
    amount: 1500,
    status: "Processing",
  },
  {
    id: 102,
    customer: "Jane Smith",
    amount: 2450,
    status: "Shipped",
  },
  {
    id: 103,
    customer: "Kiran Kumar",
    amount: 899,
    status: "Delivered",
  },
];

const statusColor = {
  Processing: "bg-yellow-100 text-yellow-700",
  Shipped: "bg-blue-100 text-blue-700",
  Delivered: "bg-green-100 text-green-700",
};

export default function Orders() {
  return (
    <div className="min-h-screen bg-gray-50 py-10 px-4 sm:px-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
          🚀 SmartOrders Pro
        </h1>

        <div className="flex justify-center gap-4 mb-8">
          <button className="px-5 py-2 bg-indigo-600 text-white rounded-xl shadow hover:bg-indigo-700 transition">
            View Orders
          </button>
          <button className="px-5 py-2 bg-green-600 text-white rounded-xl shadow hover:bg-green-700 transition">
            ➕ Add New Order
          </button>
        </div>

        <h2 className="text-xl font-semibold text-gray-700 mb-4 flex items-center">
          📦 Recent Orders
        </h2>

        <div className="grid gap-6">
          {orders.map((order) => (
            <div
              key={order.id}
              className="bg-white rounded-2xl p-6 shadow-md border border-gray-200"
            >
              <div className="flex justify-between items-center mb-2">
                <span className="text-lg font-semibold text-gray-800">
                  🧾 Order #{order.id}
                </span>
                <span
                  className={`text-sm px-3 py-1 rounded-full font-medium ${statusColor[order.status as keyof typeof statusColor]}`}
                >
                  {order.status}
                </span>
              </div>

              <p className="text-gray-600 text-sm mb-1">👤 {order.customer}</p>
              <p className="text-gray-600 text-sm">💰 ₹{order.amount}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


