//import { CognitoUserPool, CognitoUser, AuthenticationDetails } from 'amazon-cognito-identity-js';
// @ts-ignore
import { CognitoUserPool, CognitoUser, AuthenticationDetails } from 'amazon-cognito-identity-js';


const poolData = {
  UserPoolId: 'your_user_pool_id', // 🔁 replace with real value
  ClientId: 'your_client_id',       // 🔁 replace with real value
};

const userPool = new CognitoUserPool(poolData);

export const getCurrentUserSession = (): Promise<any> => {
  return new Promise((resolve, reject) => {
    const user = userPool.getCurrentUser();
    if (!user) {
      return reject('No user found');
    }

    user.getSession((err: any, session: any) => {
      if (err || !session?.isValid()) {
        return reject(err || 'Session invalid');
      }
      resolve(session);
    });
  });
};
