
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header className="bg-blue-700 text-white p-4 shadow-md flex justify-between items-center">
      <h1 className="text-xl font-bold">🚀 SmartOrders Pro</h1>
      <nav className="space-x-4">
        <Link to="/" className="hover:underline">View Orders</Link>
        <Link to="/add" className="hover:underline">Add New Order</Link>
      </nav>
    </header>
  );
};

export default Header;
