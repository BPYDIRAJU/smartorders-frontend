// src/components/AuthButtons.tsx
import React from "react";
import { useAuth } from "react-oidc-context";

const AuthButtons: React.FC = () => {
  const auth = useAuth();

  if (auth.isLoading) return <p>Loading...</p>;
  if (auth.error) return <p>Error: {auth.error.message}</p>;

  return (
    <div>
      {auth.isAuthenticated ? (
        <>
          <p>Welcome, {auth.user?.profile.email}</p>
          <button
            onClick={() => {
              auth.removeUser();
              auth.signoutRedirect();
            }}
          >
            Sign Out
          </button>
        </>
      ) : (
        <button onClick={() => auth.signinRedirect()}>Sign In</button>
      )}
    </div>
  );
};

export default AuthButtons;

