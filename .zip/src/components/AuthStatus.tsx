import React from "react";
import { useAuth } from "react-oidc-context";

const AuthStatus: React.FC = () => {
  const auth = useAuth();

  if (auth.isLoading) {
    return <p>🔄 Loading...</p>;
  }

  if (auth.error) {
    return <p>❌ Authentication error: {auth.error.message}</p>;
  }

  if (auth.isAuthenticated) {
    return (
      <div className="p-4 bg-green-100 rounded-xl shadow">
        <p className="text-green-800 font-semibold">✅ Welcome, {auth.user?.profile.name || "User"}!</p>
        <p className="text-sm text-gray-600">{auth.user?.profile.email}</p>
        <button
          onClick={() => auth.signoutRedirect()}
          className="mt-2 px-4 py-1 bg-red-600 text-white rounded hover:bg-red-700"
        >
          Sign Out
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={() => auth.signinRedirect()}
      className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
    >
      Sign In
    </button>
  );
};

export default AuthStatus;
