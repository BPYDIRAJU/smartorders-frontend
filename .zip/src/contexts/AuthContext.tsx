// src/contexts/AuthContext.tsx
import React, { createContext, useEffect, useState } from 'react';
import {
  CognitoUserPool,
  CognitoUserSession,
  CognitoUser,
} from 'amazon-cognito-identity-js';

const poolData = {
  UserPoolId: 'ap-south-1_iX353eob7',
  ClientId: '6g9i83psniun5oe6h65lvs10nm',
};

const userPool = new CognitoUserPool(poolData);

// 🔐 Helper to get session
const getCurrentUserSession = (): Promise<CognitoUserSession> => {
  const currentUser: CognitoUser | null = userPool.getCurrentUser();

  return new Promise((resolve, reject) => {
    if (!currentUser) {
      reject('No user found');
      return;
    }

    currentUser.getSession(
      (err: Error | null, session: CognitoUserSession | null) => {
        if (err || !session) {
          reject(err || 'No session');
        } else {
          resolve(session);
        }
      }
    );
  });
};

interface AuthContextType {
  session: CognitoUserSession | null;
  isAuthenticated: boolean;
}

// ✅ MAIN FIX — make sure it's **exported**
export const AuthContext = createContext<AuthContextType>({
  session: null,
  isAuthenticated: false,
});

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [session, setSession] = useState<CognitoUserSession | null>(null);

  useEffect(() => {
    getCurrentUserSession()
      .then((sess) => setSession(sess))
      .catch(() => setSession(null));
  }, []);

  const isAuthenticated = !!session;

  return (
    <AuthContext.Provider value={{ session, isAuthenticated }}>
      {children}
    </AuthContext.Provider>
  );
};







