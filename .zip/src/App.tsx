import { AuthProvider, useAuth } from "react-oidc-context";

const oidcConfig = {
  authority: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com", // 🔁 Replace with actual Cognito or other URL
  //authority: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_iX353eob7",
  //authority: "https://smartorderspro.auth.ap-south-1.amazoncognito.com",
  //authority: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_iX353eob7",

  client_id: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com/login?client_id=YOUR_CLIENT_ID&response_type=code&scope=email+openid&redirect_uri=https://d3ud2zj4au6k7a.cloudfront.net/",           // 🔁 Your Client ID
   //client_id: "6g9i83psniun5oe6h65lvs10nm",
  redirect_uri: window.location.origin + "/callback",
  scope: "openid profile email",
  response_type: "code",
};

const AppContent = () => {
  const auth = useAuth();

  if (auth.isLoading) return <div>Loading...</div>;

  if (auth.error) return <div>Error: {auth.error.message}</div>;

  if (!auth.isAuthenticated) {
    return (
      <div>
        <h2>Please login</h2>
        <button onClick={() => auth.signinRedirect()}>Login</button>
      </div>
    );
  }

  return (
    <div>
      <h1>Welcome, {auth.user?.profile?.name}</h1>
      <button onClick={() => auth.signoutRedirect()}>Logout</button>
    </div>
  );
};

const App = () => {
  return (
    <AuthProvider {...oidcConfig}>
      <AppContent />
    </AuthProvider>
  );
};

export default App;







