const isProd = window.location.origin.includes("cloudfront.net");

const oidcConfig = {
  //authority: "https://smartorderspro.auth.ap-south-1.amazoncognito.com", // ✅ Hosted UI Domain
  //authority: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_iX353eob7",
  authority: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com",

  client_id: "6g9i83psniun5oe6h65lvs10nm",
  redirect_uri: isProd
    ? "https://d3ud2zj4au6k7a.cloudfront.net/callback"
    : "http://localhost:5173/callback",
  response_type: "code",
  scope: "openid profile email",
  post_logout_redirect_uri: isProd
    ? "https://d3ud2zj4au6k7a.cloudfront.net/"
    : "http://localhost:5173/",
};

export default oidcConfig;




