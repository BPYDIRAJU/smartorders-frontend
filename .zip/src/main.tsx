import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import { AuthProvider } from "react-oidc-context";

// ✅ Replace YOUR_CLIENT_ID with actual one from App client (SmartOrdersAuthApp)
const oidcConfig = {
  //authority: "https://smartorderspro.auth.ap-south-1.amazoncognito.com",
  //authority: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_iX353eob7",
 authority: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com",

  clientId: "6g9i83psniun5oe6h65lvs10nm",
  redirectUri: "https://d3ud2zj4au6k7a.cloudfront.net",
  responseType: "code",
  scope: "openid profile email",

 // metadata: {
  //issuer: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_iX353eob7",
  //authorization_endpoint: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_iX353eob7/oauth2/authorize",
  //token_endpoint: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_iX353eob7/oauth2/token",
  //userinfo_endpoint: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_iX353eob7/oauth2/userInfo",
  //end_session_endpoint: "https://cognito-idp.ap-south-1.amazonaws.com/ap-south-1_iX353eob7/logout",
//},
//metadata: {
  //issuer: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com",
  //authorization_endpoint: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com/oauth2/authorize",
  //token_endpoint: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com/oauth2/token",
  //userinfo_endpoint: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com/oauth2/userInfo",
  //end_session_endpoint: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com/logout",
//},
metadata: {
  issuer: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com",
  authorization_endpoint: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com/oauth2/authorize",
  token_endpoint: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com/oauth2/token",
  userinfo_endpoint: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com/oauth2/userInfo",
  end_session_endpoint: "https://ap-south-1ix353eob7.auth.ap-south-1.amazoncognito.com/logout",
},



  onSignIn: async (user: any) => {
    console.log("✅ User signed in:", user);
  },
};

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <AuthProvider {...oidcConfig}>
      <App />
    </AuthProvider>
  </React.StrictMode>
);
